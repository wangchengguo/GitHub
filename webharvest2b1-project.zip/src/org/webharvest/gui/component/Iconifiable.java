package org.webharvest.gui.component;

import javax.swing.*;

/**
 * Something thet has icon.
 */
public interface Iconifiable {

    public Icon getIcon();

}