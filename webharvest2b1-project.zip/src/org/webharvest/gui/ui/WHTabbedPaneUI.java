package org.webharvest.gui.ui;

import javax.swing.plaf.basic.BasicTabbedPaneUI;

/**
 * Look & Feel for tabbed panes in application
 */
public class WHTabbedPaneUI extends BasicTabbedPaneUI {
}
